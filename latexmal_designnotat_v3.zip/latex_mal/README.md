Denne malen er laget av Per-Åsmund Grindholm, høsten 2023 og tilpasset av Carl Richard Steen Fosse.

Eksempel på bruk:
1. Opprett en bruker på overleaf.com (bruk stud-mailen)
2. Importer denne mappen som en zippet fil.
3. Slå deg løs og sjekk ut "Hjelpekoder" for noen snarveier.